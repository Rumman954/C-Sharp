﻿using System;

class Book
{
    private string bookName;
    private string bookAuthor;
    private string bookId;
    private string bookType;
    private int bookCopy;

    public Book()
    {
        // Empty constructor
    }

    public Book(string name, string author, string id, string type, int copy)
    {
        bookName = name;
        bookAuthor = author;
        bookId = id;
        bookType = type;
        bookCopy = copy;
    }

    public void ShowInfo()
    {
        Console.WriteLine($"Book Name: {bookName}");
        Console.WriteLine($"Author: {bookAuthor}");
        Console.WriteLine($"Book ID: {bookId}");
        Console.WriteLine($"Book Type: {bookType}");
        Console.WriteLine($"Book Copies: {bookCopy}");
    }

    public void AddBookCopy(int x)
    {
        bookCopy += x;
    }

    public static int bookCounter;

    public static void ShowTotalBookInfo()
    {
        Console.WriteLine($"Total Book Count: {bookCounter}");
    }
}

class Contact
{
    private string personName;
    private string personId;
    private int age;
    private string mobileNumber;
    private char gender;

    public Contact()
    {
        // Empty constructor
    }

    public Contact(string name, string id, int personAge, string number, char personGender)
    {
        personName = name;
        personId = id;
        age = personAge;
        mobileNumber = number;
        gender = personGender;
    }

    public void ShowPersonInfo()
    {
        Console.WriteLine($"Name: {personName}");
        Console.WriteLine($"ID: {personId}");
        Console.WriteLine($"Age: {age}");
        Console.WriteLine($"Mobile Number: {mobileNumber}");
        Console.WriteLine($"Gender: {gender}");
    }

    public void DetectMobileOperator()
    {
        // Detect mobile operator based on the mobile number and display it
        // You can implement this logic here.
    }
}

class Course
{
    private string courseName;
    private string courseCode;
    private int courseCredit;

    public Course()
    {
        // Empty constructor
    }

    public Course(string name, string code, int credit)
    {
        courseName = name;
        courseCode = code;
        courseCredit = credit;
    }

    public void ShowCourseInfo()
    {
        Console.WriteLine($"Course Name: {courseName}");
        Console.WriteLine($"Course Code: {courseCode}");
        Console.WriteLine($"Course Credit: {courseCredit}");
        Console.ReadLine();
    }
}

class Program
{
    static void Main()
    {
        // Create instances of the classes and demonstrate their usage
        Book book = new Book("Introduction to C#", " E. Balagurusamy", "C#2210", "3", 10);
        book.ShowInfo();
        book.AddBookCopy(5);
        book.ShowInfo();

        Contact contact = new Contact("Rumman", "21-45688-3", 23, "1234567890", 'M');
        contact.ShowPersonInfo();
        contact.DetectMobileOperator();

        Course course = new Course("Object-Oriented Programming", "CSE2210", 3);
        course.ShowCourseInfo();
    }
}
