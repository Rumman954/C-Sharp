﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace First_task
{
    class Program
    {
        static void Main(string[] args)
        {
                Console.WriteLine("Calculator");
                Console.WriteLine("Enter an operation (+, -, *, /):");

                char operation = Console.ReadKey().KeyChar;
                Console.WriteLine(); 

                Console.Write("Enter the first number: ");
                if (double.TryParse(Console.ReadLine(), out double num1))
                {
                    Console.Write("Enter the second number: ");
                    if (double.TryParse(Console.ReadLine(), out double num2))
                    {
                        double result = 0.0;

                        switch (operation)
                        {
                            case '+':
                                result = num1 + num2;
                                break;
                            case '-':
                                result = num1 - num2;
                                break;
                            case '*':
                                result = num1 * num2;
                                break;
                            case '/':
                                if (num2 != 0)
                                {
                                    result = num1 / num2;
                                }
                                else
                                {
                                    Console.WriteLine("Division by zero is not allowed.");
                                    Console.ReadLine();
                                return; 
                                }
                                break;
                            default:
                                Console.WriteLine("Invalid operation.");
                                Console.ReadLine();
                            return; 
                        }

                        Console.WriteLine($"Result: {result}");
                    }
                    else
                    {
                        Console.WriteLine("Invalid input for the second number.");
                        Console.ReadLine();
                }
                }
                else
                {
                    Console.WriteLine("Invalid input for the first number.");
                    Console.ReadLine();
                }
            }
        }
    }