﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    class Student
    {
        public int StudentId { get; set; }
        public string Name { get; set; }
        private List<Course> enrolledCourses = new List<Course>();

        public Student(int studentId, string name)
        {
            StudentId = studentId;
            Name = name;
        }

        public void EnrollInCourse(Course course)
        {
            if (enrolledCourses.Count < 5 && course.AddStudent(this))
            {
                enrolledCourses.Add(course);
                Console.WriteLine($"{Name} is enrolled in {course.CourseName}");
            }
            else
            {
                Console.WriteLine($"{Name} cannot enroll in {course.CourseName}. Maximum enrollment reached or the course is full.");
            }
        }

        public void DropCourse(Course course)
        {
            if (enrolledCourses.Contains(course))
            {
                enrolledCourses.Remove(course);
                course.RemoveStudent(this);
                Console.WriteLine($"{Name} has dropped {course.CourseName}");
            }
            else
            {
                Console.WriteLine($"{Name} is not enrolled in {course.CourseName}.");
            }
        }

        public void ShowEnrolledCourses()
        {
            Console.WriteLine($"{Name}'s enrolled courses:");
            foreach (var course in enrolledCourses)
            {
                Console.WriteLine(course.CourseName);
            }
        }
    }

    class Course
    {
        public int CourseId { get; set; }
        public string CourseName { get; set; }
        private List<Student> enrolledStudents = new List<Student>();

        public Course(int courseId, string courseName)
        {
            CourseId = courseId;
            CourseName = courseName;
        }

        public bool AddStudent(Student student)
        {
            if (enrolledStudents.Count < 30)
            {
                enrolledStudents.Add(student);
                return true;
            }
            return false;
        }

        public void RemoveStudent(Student student)
        {
            enrolledStudents.Remove(student);
        }

        public void ShowEnrolledStudents()
        {
            Console.WriteLine($"Students enrolled in {CourseName}:");
            foreach (var student in enrolledStudents)
            {
                Console.WriteLine(student.Name);
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Student student1 = new Student(1, "Talha");
            Student student2 = new Student(2, "Rumman");
            Course course1 = new Course(101, "Math");
            Course course2 = new Course(102, "Science");

            student1.EnrollInCourse(course1);
            student1.EnrollInCourse(course2);
            student2.EnrollInCourse(course1);

            course1.ShowEnrolledStudents();
            course2.ShowEnrolledStudents();

            student1.ShowEnrolledCourses();
            student2.ShowEnrolledCourses();
            Console.Read();
        }
    }
}
