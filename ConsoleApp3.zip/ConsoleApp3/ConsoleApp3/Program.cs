﻿using System;

class Course
{
    private string courseName;
    private string courseCode;
    private int courseCredit;

    public string CourseName
    {
        get { return courseName; }
        set { courseName = value; }
    }

    public string CourseCode
    {
        get { return courseCode; }
        set { courseCode = value; }
    }

    public int CourseCredit
    {
        get { return courseCredit; }
        set
        {
            if (value >= 0)
                courseCredit = value;
            else
                Console.WriteLine("Invalid course credit. Please enter a non-negative value.");
        }
    }

    public Course()
    {
        // Default constructor
        courseName = "Unknown";
        courseCode = "0000";
        courseCredit = 0;
    }

    public Course(string name, string code, int credit)
    {
        // Parameterized constructor
        courseName = name;
        courseCode = code;
        CourseCredit = credit; // Using the property to set the credit
    }

    public void ShowCourseInfo()
    {
        Console.WriteLine($"Course Name: {CourseName}");
        Console.WriteLine($"Course Code: {CourseCode}");
        Console.WriteLine($"Course Credit: {CourseCredit}");
    }
}
class Program
{
    static void Main(string[] args)
    {
        Course course1 = new Course("Introduction to Programming", "CS101", 3);
        Course course2 = new Course("Data Structures", "CS201", 4);

        course1.ShowCourseInfo();
        course2.ShowCourseInfo();
        Console.ReadLine();
    }
}