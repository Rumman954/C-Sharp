﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp6
{
    public interface IBasicBanking
    {
        bool Deposit(int amount);
        bool Withdraw(int amount);
    }

    public class CurrentAccount : IBasicBanking
    {
        private int balance;

        public bool Deposit(int amount)
        {
            balance += amount;
            Console.WriteLine($"Deposited: {amount}");
            DisplayBalance();
            return true;
        }

        public bool Withdraw(int amount)
        {
            if (amount <= balance)
            {
                balance -= amount;
                Console.WriteLine($"Withdrawn: {amount}");
                DisplayBalance();
                return true;
            }
            else
            {
                Console.WriteLine("Insufficient funds!");
                return false;
            }
        }

        private void DisplayBalance()
        {
            Console.WriteLine($"Current Balance: {balance}");
        }
    }

    public class SavingsAccount : IBasicBanking
    {
        private int balance;

        public bool Deposit(int amount)
        {
            balance += amount;
            Console.WriteLine($"Deposited: {amount}");
            DisplayBalance();
            return true;
        }

        public bool Withdraw(int amount)
        {
            int maxWithdrawal = (int)(balance * 0.8);

            if (amount <= maxWithdrawal)
            {
                balance -= amount;
                Console.WriteLine($"Withdrawn: {amount}");
                DisplayBalance();
                return true;
            }
            else
            {
                Console.WriteLine("Exceeded maximum withdrawal limit!");
                return false;
            }
        }

        private void DisplayBalance()
        {
            Console.WriteLine($"Current Balance: {balance}");
        }
    }

    public class OverdraftAccount : IBasicBanking
    {
        private int balance;
        private int overdraftLimit;

        public OverdraftAccount(int overdraftLimit)
        {
            this.overdraftLimit = overdraftLimit;
        }

        public bool Deposit(int amount)
        {
            balance += amount;
            Console.WriteLine($"Deposited: {amount}");
            DisplayBalance();
            return true;
        }

        public bool Withdraw(int amount)
        {
            int availableBalance = balance + overdraftLimit;

            if (amount <= availableBalance)
            {
                balance -= amount;
                Console.WriteLine($"Withdrawn: {amount}");
                DisplayBalance();
                return true;
            }
            else
            {
                Console.WriteLine("Exceeded overdraft limit!");
                return false;
            }
        }

        private void DisplayBalance()
        {
            Console.WriteLine($"Current Balance: {balance}, Overdraft Limit: {overdraftLimit}");
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            CurrentAccount currentAccount = new CurrentAccount();
            currentAccount.Deposit(1000);
            currentAccount.Withdraw(500);

            SavingsAccount savingsAccount = new SavingsAccount();
            savingsAccount.Deposit(2000);
            savingsAccount.Withdraw(1500);

            OverdraftAccount overdraftAccount = new OverdraftAccount(1000);
            overdraftAccount.Deposit(3000);
            overdraftAccount.Withdraw(2500);
            Console.Read();
        }
    }
}